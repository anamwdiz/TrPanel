#!/bin/bash

yum -y erase ld-linux.so.2 libbz2.so.1 libdb-4.7.so libgd.so.2 httpd php php-suhosin php-devel php-gd php-mbstring php-mcrypt php-intl php-imap php-mysql php-xml php-xmlrpc curl curl-devel perl-libwww-perl libxml2 libxml2-devel mysql-server zip webalizer gcc gcc-c++ httpd-devel at make mysql-devel bzip2-devel postfix postfix-perl-scripts bash-completion dovecot dovecot-mysql dovecot-pigeonhole mysql-server proftpd proftpd-mysql bind bind-utils bind-libs

# Delete Zpanel if they exists
rm -rf /etc/zpanel
rm -rf /var/zpanel

# Delete Sentora
rm -rf /etc/sentora
rm -rf /var/sentora

rm -f /root/passwords.txt
