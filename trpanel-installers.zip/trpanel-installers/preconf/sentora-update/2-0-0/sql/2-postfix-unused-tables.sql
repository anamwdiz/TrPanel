
DROP TABLE IF EXISTS  `sentora_postfix`.`domain_admins`;
DROP TABLE IF EXISTS  `sentora_postfix`.`fetchmail`;
DROP TABLE IF EXISTS  `sentora_postfix`.`log`;
DROP TABLE IF EXISTS  `sentora_postfix`.`quota`;
