
ALTER TABLE `sentora_postfix`.`admin` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`alias` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`alias_domain` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`config` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`domain` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`mailbox` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`quota2` 
ENGINE = InnoDB ;

ALTER TABLE `sentora_postfix`.`vacation` 
ENGINE = InnoDB ;
